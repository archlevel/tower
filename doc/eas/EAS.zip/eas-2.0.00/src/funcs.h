char *basename(const char *);
int validshell(const char *);
