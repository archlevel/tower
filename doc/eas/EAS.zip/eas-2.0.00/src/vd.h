void print_version(struct ServerOption *, const char *);
