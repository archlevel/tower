int myrand(void);
char *rand2str(size_t);
