void s_log(int, const char *, ...);
